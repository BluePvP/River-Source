# River Client:
Literal copy paste client of eric golde lmao, same class names, devs were so much retarded they didn't even knew that they can change the packges names.

The client developers don't even know a single bit of java lmao, when I asked them to answer the question and say the truth that they know java or not they said https://pace.is-a-skid.wtf/48eb943.png, kid is crying harder that he didn't skidded there was no fivver dev working on client lmaoo.
<img src="clowns/cryharder.png?raw=true" alt="cryharder.png">

Devs were so lazy and retarded, they didn't even bother to change name of packages or were too retarded they don't know that client will work with diff names kekw.

Owner is underage too https://pace.is-a-skid.wtf/2139a4a.png *Thanks fizzify for this screenshots.*
<img src="clowns/cryaboutit.png?raw=true" alt="cryaboutit.png">

Yeah, buddy you are not skidding https://pace.is-a-skid.wtf/cacd092.png. Dev is too retared man...
<img src="clowns/kekw.png?raw=true" alt="kekw.png">

**Some retarded kids who say that I made a shitty version of client and named it River so go to river download and open it in any decompiler lmfao.**

## TO ALL GITHUB STAFF:

Not a single line of code is orginal every thing is taken from YouTube(Eric golde).


*Don't skid this skid, code is shit. Its mcp tho.*
