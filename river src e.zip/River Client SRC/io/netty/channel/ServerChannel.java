// 
// Decompiled by Procyon v0.5.36
// 

package io.netty.channel;

public interface ServerChannel extends Channel
{
}
