// 
// Decompiled by Procyon v0.5.36
// 

package io.netty.channel.socket;

public enum InternetProtocolFamily
{
    IPv4, 
    IPv6;
}
