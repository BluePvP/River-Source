// 
// Decompiled by Procyon v0.5.36
// 

package io.netty.channel.group;

import io.netty.util.concurrent.GenericFutureListener;

public interface ChannelGroupFutureListener extends GenericFutureListener<ChannelGroupFuture>
{
}
