// 
// Decompiled by Procyon v0.5.36
// 

package io.netty.channel.udt;

import io.netty.channel.ServerChannel;

public interface UdtServerChannel extends ServerChannel, UdtChannel
{
}
