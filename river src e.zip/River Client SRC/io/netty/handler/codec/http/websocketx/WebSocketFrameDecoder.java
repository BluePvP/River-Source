// 
// Decompiled by Procyon v0.5.36
// 

package io.netty.handler.codec.http.websocketx;

import io.netty.channel.ChannelInboundHandler;

public interface WebSocketFrameDecoder extends ChannelInboundHandler
{
}
