// 
// Decompiled by Procyon v0.5.36
// 

package io.netty.handler.codec.http.websocketx;

public class WebSocket13FrameEncoder extends WebSocket08FrameEncoder
{
    public WebSocket13FrameEncoder(final boolean maskPayload) {
        super(maskPayload);
    }
}
