// 
// Decompiled by Procyon v0.5.36
// 

package io.netty.handler.codec.http.websocketx;

public class WebSocket07FrameEncoder extends WebSocket08FrameEncoder
{
    public WebSocket07FrameEncoder(final boolean maskPayload) {
        super(maskPayload);
    }
}
