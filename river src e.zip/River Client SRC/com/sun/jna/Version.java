// 
// Decompiled by Procyon v0.5.36
// 

package com.sun.jna;

interface Version
{
    public static final String VERSION = "4.5.1";
    public static final String VERSION_NATIVE = "5.2.0";
}
