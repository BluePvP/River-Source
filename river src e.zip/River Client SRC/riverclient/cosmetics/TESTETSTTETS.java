// 
// Decompiled by Procyon v0.5.36
// 

package clientname.cosmetics;

public class TESTETSTTETS
{
}
