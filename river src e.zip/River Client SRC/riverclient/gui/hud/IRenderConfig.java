// 
// Decompiled by Procyon v0.5.36
// 

package clientname.gui.hud;

public interface IRenderConfig
{
    void save(final ScreenPosition p0);
    
    ScreenPosition load();
}
