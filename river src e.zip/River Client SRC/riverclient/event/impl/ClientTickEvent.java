// 
// Decompiled by Procyon v0.5.36
// 

package clientname.event.impl;

import clientname.event.Event;

public class ClientTickEvent extends Event
{
}
