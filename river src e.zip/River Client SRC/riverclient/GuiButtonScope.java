// 
// Decompiled by Procyon v0.5.36
// 

package clientname;

import net.minecraft.client.gui.GuiButton;

public class GuiButtonScope extends GuiButton
{
    public GuiButtonScope(final int buttonId, final int x, final int y, final int widthIn, final int heightIn, final String buttonText) {
        super(buttonId, x, y, widthIn, heightIn, buttonText);
    }
}
