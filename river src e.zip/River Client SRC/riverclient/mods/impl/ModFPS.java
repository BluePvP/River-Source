// 
// Decompiled by Procyon v0.5.36
// 

package clientname.mods.impl;

import clientname.ChromaText;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.GlStateManager;
import clientname.Client;
import clientname.gui.hud.ScreenPosition;
import clientname.mods.ModDraggable;

public class ModFPS extends ModDraggable
{
    @Override
    public int getWidth() {
        return 50;
    }
    
    @Override
    public int getHeight() {
        return ModFPS.font.FONT_HEIGHT;
    }
    
    @Override
    public void render(final ScreenPosition pos) {
        if (Client.ModFPS) {
            if (!Client.ChromaText) {
                GlStateManager.pushMatrix();
                Minecraft.getMinecraft().fontRendererObj.drawStringWithShadow(String.valueOf(String.valueOf(Client.KlammerFarbe)) + "[" + Client.ModFarbe + "FPS" + Client.KlammerFarbe + "] " + Minecraft.getDebugFPS(), (float)pos.getAbsoluteX(), (float)pos.getAbsoluteY(), -1);
                GlStateManager.popMatrix();
            }
            else {
                ChromaText.drawChromaString("[FPS] " + Minecraft.getDebugFPS(), pos.getAbsoluteX(), pos.getAbsoluteY(), true);
            }
        }
    }
}
