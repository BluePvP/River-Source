// 
// Decompiled by Procyon v0.5.36
// 

package clientname.mods.impl;

import clientname.ChromaText;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.GlStateManager;
import clientname.gui.hud.ScreenPosition;
import clientname.Client;
import clientname.mods.ModDraggable;

public class ModClientName extends ModDraggable
{
    @Override
    public int getWidth() {
        return ModClientName.font.getStringWidth(String.valueOf(String.valueOf(Client.ModFarbe)) + Client.ClientName);
    }
    
    @Override
    public int getHeight() {
        return ModClientName.font.FONT_HEIGHT;
    }
    
    @Override
    public void render(final ScreenPosition pos) {
        if (!Client.ChromaText) {
            GlStateManager.pushMatrix();
            Minecraft.getMinecraft().fontRendererObj.drawStringWithShadow(String.valueOf(String.valueOf(Client.ModFarbe)) + Client.ClientName, (float)pos.getAbsoluteX(), (float)pos.getAbsoluteY(), -1);
            GlStateManager.popMatrix();
        }
        else {
            ChromaText.drawChromaString(Client.ClientName, pos.getAbsoluteX(), pos.getAbsoluteY(), true);
        }
    }
}
