// 
// Decompiled by Procyon v0.5.36
// 

package clientname.mods.impl;

import org.lwjgl.LWJGLException;
import org.lwjgl.opengl.Display;
import clientname.gui.hud.ScreenPosition;
import clientname.mods.ModDraggable;

public class ModFullscreen extends ModDraggable
{
    @Override
    public int getWidth() {
        return 0;
    }
    
    @Override
    public int getHeight() {
        return 0;
    }
    
    @Override
    public void render(final ScreenPosition pos) {
        System.setProperty("org.lwjgl.opengl.Window.undecorated", "true");
        Display.setLocation(0, 0);
        try {
            Display.setFullscreen(false);
        }
        catch (LWJGLException e) {
            e.printStackTrace();
        }
        Display.setResizable(false);
    }
}
